import pytest
from services.auth_service import hash_password, verify_password, create_access_token, verify_token


def test_password_hashing():
    pw = "MySecureP@ss1"
    hashed = hash_password(pw)
    assert hashed != pw
    assert verify_password(pw, hashed)
    assert not verify_password("WrongPassword1", hashed)


def test_token_creation():
    token = create_access_token("user-123", is_admin=False)
    payload = verify_token(token)
    assert payload["sub"] == "user-123"
    assert payload["admin"] is False


def test_admin_token():
    token = create_access_token("admin-456", is_admin=True)
    payload = verify_token(token)
    assert payload["admin"] is True
