from datetime import datetime
from database import get_session
from models.order import Order, OrderItem, OrderStatus
from models.product import Product


def create_order(user_id: str, product_ids: list[str], quantities: list[int], shipping_address: str) -> Order:
    session = next(get_session())
    total = 0.0
    items = []
    for pid, qty in zip(product_ids, quantities):
        product = session.query(Product).filter(Product.id == pid).first()
        if not product:
            continue
        total += product.price * qty
        items.append(OrderItem(product_id=pid, quantity=qty, unit_price=product.price))

    order = Order(
        user_id=user_id,
        status=OrderStatus.PENDING,
        total_amount=total,
        shipping_address=shipping_address,
        created_at=datetime.utcnow(),
    )
    session.add(order)
    session.flush()

    for item in items:
        item.order_id = order.id
        session.add(item)

    session.commit()
    session.refresh(order)
    return order


def get_order_by_id(order_id: str) -> Order | None:
    session = next(get_session())
    return session.query(Order).filter(Order.id == order_id).first()


def list_user_orders(user_id: str) -> list[Order]:
    session = next(get_session())
    return session.query(Order).filter(Order.user_id == user_id).order_by(Order.created_at.desc()).all()


def update_order_status(order_id: str, status: OrderStatus) -> Order | None:
    session = next(get_session())
    order = session.query(Order).filter(Order.id == order_id).first()
    if not order:
        return None
    order.status = status
    session.commit()
    return order


def cancel_order(order_id: str, user_id: str) -> bool:
    session = next(get_session())
    order = session.query(Order).filter(Order.id == order_id, Order.user_id == user_id).first()
    if not order or order.status not in (OrderStatus.PENDING, OrderStatus.CONFIRMED):
        return False
    order.status = OrderStatus.CANCELLED
    session.commit()
    return True
