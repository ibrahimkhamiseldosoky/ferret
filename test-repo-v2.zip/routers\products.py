from fastapi import APIRouter, HTTPException
from services.product_service import get_product_by_id, list_products, search_products, create_product, update_stock

router = APIRouter(tags=["products"])


@router.get("")
async def get_products(category: str = None, page: int = 1):
    if category:
        return search_products(category=category, page=page)
    return list_products(page=page)


@router.get("/{product_id}")
async def get_product(product_id: str):
    product = get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@router.post("")
async def add_product(name: str, price: float, category: str, stock: int = 0):
    return create_product(name=name, price=price, category=category, stock_quantity=stock)
