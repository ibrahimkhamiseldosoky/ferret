import pytest
from services.product_service import create_product, get_product_by_id, update_stock


def test_create_product():
    product = create_product("Laptop", 999.99, "electronics", 10)
    assert product.name == "Laptop"
    assert product.price == 999.99


def test_update_stock():
    product = create_product("Phone", 599.99, "electronics", 5)
    updated = update_stock(product.id, -2)
    assert updated.stock_quantity == 3
