import sendgrid
from sendgrid.helpers.mail import Mail
from config import settings

sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)


def send_order_confirmation(email: str, order_id: str) -> bool:
    message = Mail(
        from_email="noreply@ecommerce.dev",
        to_emails=email,
        subject=f"Order {order_id} Confirmed",
        html_content=f"<p>Your order {order_id} has been received.</p>",
    )
    try:
        sg.send(message)
        return True
    except Exception:
        return False


def send_password_reset(email: str, reset_token: str) -> bool:
    message = Mail(
        from_email="noreply@ecommerce.dev",
        to_emails=email,
        subject="Password Reset",
        html_content=f"<p>Reset token: {reset_token}</p>",
    )
    try:
        sg.send(message)
        return True
    except Exception:
        return False
