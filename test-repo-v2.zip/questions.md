# Test Questions for E-Commerce API Repo

## Architecture Questions
1. "Explain the repository" (or "Explain Repository")
2. "What is the overall architecture of this project?"
3. "Describe how the services are organized"

## Auth Flow
4. "Show Authentication" (or "Show Authentication")
5. "How does the login flow work from request to database?"
6. "How are passwords stored and verified?"

## Request Flow
7. "Show Request Flow" (or "Show Request Flow")
8. "Trace the flow of placing an order from API to database"
9. "How does the payment processing pipeline work?"

## Service Discovery
10. "Show Main Services" (or "Show Main Services")
11. "What services does this application have and what are their responsibilities?"

## Dead Code
12. "Find Dead Code" (or "Find Dead Code")
13. "Are there any unused files or services?"

## Specific Questions
14. "How does the product search work?"
15. "What happens when a user registers?"
16. "Explain the order cancellation flow"
17. "How are notifications sent?"
18. "What validation is done on user input?"
19. "How does the rate limiting decorator work?"
20. "Explain the relationship between orders, payments, and users"
