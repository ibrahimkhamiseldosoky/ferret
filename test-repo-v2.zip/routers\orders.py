from fastapi import APIRouter, Depends, HTTPException
from services.auth_service import get_current_user
from services.order_service import create_order, get_order_by_id, list_user_orders, update_order_status, cancel_order
from services.product_service import update_stock
from services.notification_service import send_order_confirmation
from models.user import User
from utils.validators import validate_shipping_address

router = APIRouter(tags=["orders"])


@router.post("")
async def place_order(
    product_ids: list[str],
    quantities: list[int],
    shipping_address: str,
    current_user: User = Depends(get_current_user),
):
    if not validate_shipping_address(shipping_address):
        raise HTTPException(status_code=400, detail="Invalid shipping address")
    order = create_order(current_user.id, product_ids, quantities, shipping_address)
    for pid, qty in zip(product_ids, quantities):
        update_stock(pid, -qty)
    send_order_confirmation(current_user.email, order.id)
    return order


@router.get("/{order_id}")
async def get_order(order_id: str):
    order = get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.get("")
async def get_my_orders(current_user: User = Depends(get_current_user)):
    return list_user_orders(current_user.id)


@router.post("/{order_id}/cancel")
async def cancel_order_route(order_id: str, current_user: User = Depends(get_current_user)):
    result = cancel_order(order_id, current_user.id)
    if not result:
        raise HTTPException(status_code=400, detail="Cannot cancel order")
    return {"detail": "Order cancelled"}
