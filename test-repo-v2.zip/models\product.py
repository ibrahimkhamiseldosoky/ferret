from enum import Enum
from sqlalchemy import Column, String, Float, Integer, Enum as SAEnum
from sqlalchemy.orm import relationship
from database import Base
import uuid


class ProductCategory(str, Enum):
    ELECTRONICS = "electronics"
    CLOTHING = "clothing"
    FOOD = "food"
    BOOKS = "books"
    HOME = "home"


class Product(Base):
    __tablename__ = "products"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    description = Column(String)
    price = Column(Float, nullable=False)
    category = Column(SAEnum(ProductCategory))
    stock_quantity = Column(Integer, default=0)
    image_url = Column(String)

    order_items = relationship("OrderItem", back_populates="product")
