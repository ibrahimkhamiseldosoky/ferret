import os


class Settings:
    APP_NAME: str = os.getenv("APP_NAME", "E-Commerce API")
    DEBUG: bool = os.getenv("DEBUG", "true").lower() == "true"
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql://localhost:5432/ecommerce")
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev-secret-key")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRY_HOURS: int = 24
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000", "http://localhost:5173"]
    STRIPE_API_KEY: str = os.getenv("STRIPE_API_KEY", "sk_test_placeholder")
    SENDGRID_API_KEY: str = os.getenv("SENDGRID_API_KEY", "sg_test_placeholder")
    AWS_S3_BUCKET: str = os.getenv("AWS_S3_BUCKET", "dev-uploads")
    PAGE_SIZE: int = 20
    RATE_LIMIT_PER_MINUTE: int = 60


settings = Settings()
