import pytest
from services.product_service import create_product
from services.order_service import create_order, get_order_by_id


def test_order_total_calculation():
    p1 = create_product("Book", 15.99, "books", 20)
    p2 = create_product("Pen", 2.50, "home", 100)
    order = create_order("user-1", [p1.id, p2.id], [2, 3], "789 Pine Rd")
    expected = (15.99 * 2) + (2.50 * 3)
    assert order.total_amount == expected
