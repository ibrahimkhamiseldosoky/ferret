from database import get_session
from models.product import Product, ProductCategory


def get_product_by_id(product_id: str) -> Product | None:
    session = next(get_session())
    return session.query(Product).filter(Product.id == product_id).first()


def list_products(page: int = 1, page_size: int = 20) -> list[Product]:
    session = next(get_session())
    offset = (page - 1) * page_size
    return session.query(Product).offset(offset).limit(page_size).all()


def search_products(category: str = None, query: str = None, page: int = 1, page_size: int = 20) -> list[Product]:
    session = next(get_session())
    q = session.query(Product)
    if category:
        q = q.filter(Product.category == category)
    if query:
        q = q.filter(Product.name.ilike(f"%{query}%"))
    offset = (page - 1) * page_size
    return q.offset(offset).limit(page_size).all()


def create_product(name: str, price: float, category: str, stock_quantity: int = 0) -> Product:
    product = Product(name=name, price=price, category=category, stock_quantity=stock_quantity)
    session = next(get_session())
    session.add(product)
    session.commit()
    session.refresh(product)
    return product


def update_stock(product_id: str, quantity_change: int) -> Product | None:
    session = next(get_session())
    product = session.query(Product).filter(Product.id == product_id).first()
    if not product:
        return None
    product.stock_quantity += quantity_change
    session.commit()
    return product
