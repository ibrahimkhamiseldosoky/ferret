from fastapi import APIRouter, Depends, HTTPException
from services.auth_service import get_current_user
from services.user_service import get_user_by_id, update_user, delete_user, list_users
from models.user import User
from utils.decorators import require_admin

router = APIRouter(tags=["users"])


@router.get("/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return {"id": current_user.id, "email": current_user.email, "username": current_user.username}


@router.get("/{user_id}")
async def get_user(user_id: str):
    user = get_user_by_id(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.get("")
async def get_users(page: int = 1, current_user: User = Depends(require_admin)):
    return list_users(page=page)
