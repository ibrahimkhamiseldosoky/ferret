from database import get_session
from models.user import User
from services.auth_service import hash_password


def create_user(email: str, username: str, password: str) -> User:
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password(password),
    )
    session = next(get_session())
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


def get_user_by_email(email: str) -> User | None:
    session = next(get_session())
    return session.query(User).filter(User.email == email).first()


def get_user_by_id(user_id: str) -> User | None:
    session = next(get_session())
    return session.query(User).filter(User.id == user_id).first()


def update_user(user_id: str, **kwargs) -> User | None:
    session = next(get_session())
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        return None
    for key, value in kwargs.items():
        setattr(user, key, value)
    session.commit()
    return user


def delete_user(user_id: str) -> bool:
    session = next(get_session())
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        return False
    session.delete(user)
    session.commit()
    return True


def list_users(page: int = 1, page_size: int = 20) -> list[User]:
    session = next(get_session())
    offset = (page - 1) * page_size
    return session.query(User).offset(offset).limit(page_size).all()
