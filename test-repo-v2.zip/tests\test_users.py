import pytest
from services.user_service import create_user, get_user_by_email, get_user_by_id


def test_create_user():
    user = create_user("test@example.com", "testuser", "TestP@ss1")
    assert user.email == "test@example.com"
    assert user.username == "testuser"


def test_get_user_by_email():
    user = get_user_by_email("test@example.com")
    assert user is not None
    assert user.email == "test@example.com"


def test_get_user_by_id():
    user = get_user_by_email("test@example.com")
    found = get_user_by_id(user.id)
    assert found is not None
    assert found.id == user.id
