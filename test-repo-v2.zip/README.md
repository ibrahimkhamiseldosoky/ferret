# E-Commerce API

A mock e-commerce backend built with FastAPI and SQLAlchemy.

## Architecture

- **FastAPI** application with RESTful API
- **SQLAlchemy** ORM with PostgreSQL
- **JWT** authentication with bcrypt password hashing
- **Stripe** payment processing integration
- **SendGrid** email notifications

## Services

- **Auth** — user registration, login, token management
- **Users** — user CRUD, profile management
- **Products** — product catalog, search, stock management
- **Orders** — order creation, status management, cancellation
- **Payments** — payment processing, refunds via Stripe
- **Notifications** — email confirmations via SendGrid

## Project Structure

```
routers/     — API route handlers
services/    — Business logic layer
models/      — SQLAlchemy ORM models
utils/       — Validators, formatters, decorators
tests/       — pytest test suite
```
