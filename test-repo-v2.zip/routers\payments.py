from fastapi import APIRouter, Depends, HTTPException
from services.auth_service import get_current_user
from services.payment_service import process_payment, get_payment_by_order, refund_payment
from models.user import User

router = APIRouter(tags=["payments"])


@router.post("/pay")
async def pay(order_id: str, current_user: User = Depends(get_current_user)):
    result = process_payment(order_id, current_user.id)
    if not result:
        raise HTTPException(status_code=400, detail="Payment failed")
    return result


@router.get("/{order_id}")
async def get_payment(order_id: str):
    payment = get_payment_by_order(order_id)
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return payment


@router.post("/{payment_id}/refund")
async def refund(payment_id: str, current_user: User = Depends(require_admin)):
    result = refund_payment(payment_id)
    if not result:
        raise HTTPException(status_code=400, detail="Refund failed")
    return {"detail": "Refund processed"}
