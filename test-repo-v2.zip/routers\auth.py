from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from services.auth_service import authenticate_user, create_access_token, verify_token
from services.user_service import create_user
from utils.validators import validate_email, validate_password_strength
from database import get_session

router = APIRouter(tags=["auth"])


class LoginRequest(BaseModel):
    email: str
    password: str


class RegisterRequest(BaseModel):
    email: str
    username: str
    password: str


@router.post("/login")
async def login(req: LoginRequest):
    user = authenticate_user(req.email, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token(user.id, user.is_admin)
    return {"access_token": token, "token_type": "bearer"}


@router.post("/register")
async def register(req: RegisterRequest):
    if not validate_email(req.email):
        raise HTTPException(status_code=400, detail="Invalid email")
    if not validate_password_strength(req.password):
        raise HTTPException(status_code=400, detail="Password too weak")
    user = create_user(req.email, req.username, req.password)
    token = create_access_token(user.id, user.is_admin)
    return {"access_token": token, "token_type": "bearer", "user_id": user.id}
