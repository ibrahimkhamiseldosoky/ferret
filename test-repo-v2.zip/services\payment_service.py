import stripe
from datetime import datetime
from database import get_session
from models.payment import Payment, PaymentStatus
from models.order import Order, OrderStatus
from services.order_service import get_order_by_id, update_order_status
from config import settings

stripe.api_key = settings.STRIPE_API_KEY


def process_payment(order_id: str, user_id: str) -> dict | None:
    order = get_order_by_id(order_id)
    if not order or order.user_id != user_id:
        return None

    try:
        intent = stripe.PaymentIntent.create(
            amount=int(order.total_amount * 100),
            currency="usd",
            metadata={"order_id": order_id},
        )

        session = next(get_session())
        payment = Payment(
            order_id=order_id,
            amount=order.total_amount,
            status=PaymentStatus.PROCESSING,
            stripe_payment_intent_id=intent.id,
            created_at=datetime.utcnow(),
        )
        session.add(payment)
        session.commit()

        return {"payment_id": payment.id, "client_secret": intent.client_secret}
    except stripe.error.StripeError:
        return None


def get_payment_by_order(order_id: str) -> Payment | None:
    session = next(get_session())
    return session.query(Payment).filter(Payment.order_id == order_id).first()


def refund_payment(payment_id: str) -> bool:
    session = next(get_session())
    payment = session.query(Payment).filter(Payment.id == payment_id).first()
    if not payment or payment.status != PaymentStatus.COMPLETED:
        return False

    try:
        stripe.Refund.create(payment_intent=payment.stripe_payment_intent_id)
        payment.status = PaymentStatus.REFUNDED
        session.commit()
        return True
    except stripe.error.StripeError:
        return False
