import pytest
from services.product_service import create_product
from services.order_service import create_order, get_order_by_id, cancel_order


def test_create_order():
    product = create_product("Widget", 19.99, "home", 100)
    order = create_order("user-1", [product.id], [2], "123 Main St, City")
    assert order.total_amount == 39.98
    assert len(order.items) == 1


def test_cancel_order():
    product = create_product("Gadget", 49.99, "electronics", 50)
    order = create_order("user-1", [product.id], [1], "456 Oak Ave")
    result = cancel_order(order.id, "user-1")
    assert result is True
