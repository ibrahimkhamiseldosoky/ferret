from enum import Enum
from sqlalchemy import Column, String, Float, Enum as SAEnum
from sqlalchemy.orm import relationship
from database import Base
import uuid


class PaymentStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"


class Payment(Base):
    __tablename__ = "payments"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    order_id = Column(String, nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String, default="USD")
    status = Column(SAEnum(PaymentStatus), default=PaymentStatus.PENDING)
    stripe_payment_intent_id = Column(String)
    created_at = Column(DateTime)

    order = relationship("Order", back_populates="payment")
