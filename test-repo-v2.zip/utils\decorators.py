from functools import wraps
from fastapi import Depends, HTTPException
from services.auth_service import get_current_user
from models.user import User


def require_admin(func):
    @wraps(func)
    async def wrapper(*args, current_user: User = Depends(get_current_user), **kwargs):
        if not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Admin access required")
        return await func(*args, current_user=current_user, **kwargs)
    return wrapper


def rate_limit(max_per_minute: int):
    from datetime import datetime, timedelta
    calls = []

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            now = datetime.utcnow()
            cutoff = now - timedelta(minutes=1)
            while calls and calls[0] < cutoff:
                calls.pop(0)
            if len(calls) >= max_per_minute:
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            calls.append(now)
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def log_execution(func):
    @wraps(func)
    async def wrapper(*args, **kwargs):
        print(f"Executing {func.__name__}")
        result = await func(*args, **kwargs)
        print(f"Finished {func.__name__}")
        return result
    return wrapper
